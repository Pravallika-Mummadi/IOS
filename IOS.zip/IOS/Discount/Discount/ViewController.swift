//
//  ViewController.swift
//  Discount
//
//  Created by Pravallika Mummadi on 9/21/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL1: UITextField!
    
    @IBOutlet weak var inputOL2: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func CalculateButton(_ sender: UIButton) {
        
        //read input from text fields
        var amount = Double(inputOL1.text!) ?? 0.0
        var discountrate = Double(inputOL2.text!) ?? 0.0
        
        //calculate price after discount
        func priceafterdiscount(amount1:Double,discountrate1:Double)->Double{
            return amount-((amount * discountrate)/100)
        }
        
        //printing the price in the label
        outputOL.text! = "The price after discount is \(priceafterdiscount(amount1:amount,discountrate1:amount))"
    }
    
}


//
//  ViewController.swift
//  Mummadi_SampleApp
//
//  Created by Pravallika Mummadi  on 11/2/23.
//
import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var songIdOutlet: UITextField!
    
    
    var givenSong = Song()
    
   
    var isSong = false
    
  
    var songsArray = songs
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    @IBAction func searchBTN(_ sender: Any) {
       
        let enteredID = songIdOutlet.text!
        
      
        for song in songsArray {
            print(song.id)
            if enteredID == song.id{
               
                givenSong = song
               
                isSong = true
                
            }
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "resultSegue"{
           
            let destination = segue.destination as! ResultViewController
            
            
           
            if isSong {
                destination.songObj = givenSong
                
            }
            else{
               
              
                destination.guestUser = true
            }
            
            
        }
    }
    
}


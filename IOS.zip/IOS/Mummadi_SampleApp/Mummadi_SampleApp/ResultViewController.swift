//
//  StudentViewController.swift
//  Mummadi_SampleApp
//
//  Created by Pravallika Mummadi  on 11/2/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    @IBOutlet weak var imageViewOL: UIImageView!
    @IBOutlet weak var SongNameOutlet: UILabel!
    @IBOutlet weak var singerOL: UILabel!
    @IBOutlet weak var writerOL: UILabel!
    
    @IBOutlet weak var viewBTN: UIButton!
    
    
    @IBOutlet weak var musicDirOL: UILabel!
    
    var image = ""
   
    var songObj = Song()
    
    var guestUser:Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if guestUser {
            
            singerOL.isHidden = true
            writerOL.text = "Unknown song found"
            SongNameOutlet.isHidden = true
          //  viewBTN.isHidden = true
            musicDirOL.isHidden = true
            imageViewOL.isHidden = true
            
        }else{
            
            
            
            image = songObj.img
            SongNameOutlet.text = "Song Name: " + songObj.name
            singerOL.text = "Singer " + songObj.singer
            writerOL.text = "Writer: " + songObj.lyricWriter
            musicDirOL.text = "MusicDir: "+songObj.musicDir
            
            imageViewOL.image = UIImage(named: image)
            self.imageViewOL.frame.origin.x = view.frame.width
            
        }
        
    }
    

    
    
    override func viewDidAppear(_ animated: Bool) {
        UIView.animate(withDuration: 0.3){
            
            self.imageViewOL.frame.origin.x = 70
           
            
            

    }
        
    }
        /*
         // MARK: - Navigation
         
         // In a storyboard-based application, you will often want to do a little preparation before navigation
         override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
         // Get the new view controller using segue.destination.
         // Pass the selected object to the new view controller.
         }
         */
        
    }


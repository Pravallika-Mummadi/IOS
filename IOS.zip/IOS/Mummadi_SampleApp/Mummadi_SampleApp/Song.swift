//
//  Student.swift
//  Mummadi_SampleApp
//
//  Created by Pravallika Mummadi on 11/3/23.
//

import Foundation

struct Song{
    
    var id = ""
    var name = ""
    var singer = ""
    var lyricWriter = ""
    var musicDir = ""
    var img = ""
    
    var songDetails:[Details] = []
    
    
}

struct Details{
    
    var cost = ""
    var discount = ""
    
}

let s1 = Song(id: "1", name:"Natu Natu" , singer: "Rahul Sipligunj", lyricWriter:"Chandrabose",musicDir: "M. M. Keeravaani",img: "NN", songDetails:[
    Details(cost: "23",discount:"0.25")
    ] )

let s2 = Song(id: "2", name:"Lingidi Lingidi",singer: "P. Raghu", lyricWriter:"P. Raghu",musicDir: "Midhun Mukundan",img: "lingidi", songDetails:[
    Details(cost: "30", discount:"0.15"),
    ] )
let s3 = Song(id: "3", name:"Na roja Nuve" , singer: "Hesham Abdul Wahab", lyricWriter:"Shiva Nirvana",musicDir: "Hesham Abdul Wahab",img: "na roja nuve", songDetails:[
    Details(cost: "27", discount:"0.12"),
    ] )
let s4 = Song(id: "4", name:"Neeve" , singer: "G.V. Prakash Kumar", lyricWriter:"Anantha Sriram",musicDir: "G.V. Prakash Kumar",img: "neeve", songDetails:[
    Details(cost: "24", discount:"0.35"),
    ] )
let s5 = Song(id: "5", name:"urike urike" , singer: "Sid Sriram ", lyricWriter:"MM Sreelekha",musicDir: "Shadab Rayeen ",img: "urike urike", songDetails:[
    Details(cost: "19", discount:"0.10"),
    ] )
let songs = [s1,s2,s3,s4,s5]

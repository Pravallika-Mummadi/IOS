//
//  ViewController.swift
//  Coordinates_Demo2
//
//  Created by Pravallika Mummadi on 10/17/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageViewOutlet: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //minX , minY represents top left corner of imageViewOutlet
        let minX = imageViewOutlet.frame.minX
        let minY = imageViewOutlet.frame.minY
        print(minX,",",minY)
        
        //maxX , maxY represents bottom right corner of imageViewOutlet
        let maxX = imageViewOutlet.frame.maxX
        let maxY = imageViewOutlet.frame.maxY
        print(maxX,",",maxY)
        
        //midX , midY represents center  of imageViewOutlet
        let midX = imageViewOutlet.frame.midX
        let midY = imageViewOutlet.frame.midY
        print(midX,",",midY)
        
        //Display image at top left corner of the view
        imageViewOutlet.frame.origin.x = 0
        imageViewOutlet.frame.origin.y = 0
        
        //Display image at top right corner of the view
        imageViewOutlet.frame.origin.x = 293
        imageViewOutlet.frame.origin.y = 0
        
        //Display image at bottom left  corner of the view
        imageViewOutlet.frame.origin.x = 0
        imageViewOutlet.frame.origin.y = 752
        
        //Display image at bottom right  corner of the view
        imageViewOutlet.frame.origin.x = 293
        imageViewOutlet.frame.origin.y = 752
        
        //Display image at center of the view( x = 393/2 - 50 , y = 852/2 - 50)
        imageViewOutlet.frame.origin.x = 146.5
        imageViewOutlet.frame.origin.y = 376
        
    }

    
    
}


//
//  ViewController.swift
//  Mummadi_Exam01
//
//  Created by Pravallika Mummadi on 10/5/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var NameInputOL: UITextField!
    
    @IBOutlet weak var RoomTypeInputOL: UITextField!
    
    @IBOutlet weak var MembershipInputOL: UITextField!
    
    @IBOutlet weak var Imagedisplay: UIImageView!
    
 
    @IBOutlet weak var OutputOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    
    
    @IBAction func CalculatePriceBTN(_ sender: UIButton) {
        
    //read input from user
        var name = NameInputOL.text!
        var roomtype = RoomTypeInputOL.text!
        var membership = MembershipInputOL.text!

        var singlebedprice : Double = 74.99;
        var doublebedprice : Double = 84.99;
        var afterdiscountprice : Double;
        var pricewithtax :Double;
        var pricewithtaxrounded :Double;
        var discountrate = 0.05
        var taxrate = 0.1675
        
        //Check the conditions
        if (roomtype.uppercased() == "SINGLE-BED")
        {
            if(membership.uppercased() == "YES")
            {
                
                afterdiscountprice = singlebedprice - (singlebedprice * discountrate)
                pricewithtax = afterdiscountprice + (afterdiscountprice*taxrate)
                pricewithtaxrounded = round(pricewithtax*100)/100
                
                OutputOL.text! = ("Dear \(name),You have made a reservation at Bearcat Motel for a Single-Bed at price of $\(pricewithtaxrounded) including tax.")
                
                
                Imagedisplay.image = UIImage(named: "Single_Img" )
            }
            else{
                
                pricewithtax = singlebedprice + (singlebedprice*taxrate)
                pricewithtaxrounded = round(pricewithtax*100)/100
                
                OutputOL.text! = ("Dear \(name),You have made a reservation at Bearcat Motel for a Single-Bed at price of $\(pricewithtaxrounded) including tax.")
                
                
                Imagedisplay.image = UIImage(named: "Single_Img" )
                
            }
        }
        else if (roomtype.uppercased() == "DOUBLE-BED")
        {
            if(membership.uppercased() == "YES")
            {
                
                afterdiscountprice = doublebedprice - (doublebedprice * discountrate)
                pricewithtax = afterdiscountprice + (afterdiscountprice*taxrate)
                pricewithtaxrounded = round(pricewithtax*100)/100
                OutputOL.text! = ("Dear \(name),You have made a reservation at Bearcat Motel for a Double-Bed at price of $\(pricewithtaxrounded) including tax.")
                
                
                Imagedisplay.image = UIImage(named: "Double_Img" )
            }
            else{
                
                pricewithtax = doublebedprice + (doublebedprice*taxrate)
                pricewithtaxrounded = round(pricewithtax*100)/100
                OutputOL.text! = ("Dear \(name),You have made a reservation at Bearcat Motel for a Double-Bed at price of $\(pricewithtaxrounded) including tax.")
                
                
                Imagedisplay.image = UIImage(named: "Double_Img" )
                
            }
        }
        
        
        else
        {
            OutputOL.text! = "No room is available with your preference"
            Imagedisplay.image = UIImage(named: "NoRoom_Img")
        }

        
        
    }
    
    @IBAction func ResetBTN(_ sender: UIButton) {
        NameInputOL.text! = ""
        RoomTypeInputOL.text! = ""
        MembershipInputOL.text! = ""
        Imagedisplay.image = UIImage(named: "")
        
    }
}


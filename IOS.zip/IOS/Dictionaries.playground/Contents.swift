import UIKit

var greeting = "Hello, playground"
var capitals = ["Arkansas":"LittleRock","Georgia":"Atlanta"]
print(capitals)
print(capitals.count)

var number = [1:"One",2:"Two",3:"Three"]
print(number)

number[4] = "Four"
print(number)


for(key,values) in number{
    print(key)
    print(values)
}


var players : Set<String> = ["David Warner", "Viru"]
print(players.count)

players.insert("Max")
print(players)


var primeNumbers : Set<Int> = [2,3,5,7,11,13]
var numbersList : Set<Int> = [1,2,3,4,5]

var unionSet : Set<Int> = primeNumbers.union(numbersList)
print(unionSet.sorted())

var symmDiffSet :Set<Int> = primeNumbers.symmetricDifference(numbersList)
print(symmDiffSet)

var someInts: [Int] = []
var stringarray: [String] = []
print("someInts is of type [Int] with \(someInts.count) items.")
print("stringarray is of type [String] with \(stringarray.count) items.")

var someInts1: [Int] = [8,8,8,8,8,8]
print(someInts1)

someInts1.append(4)
print(someInts1)
someInts1 = []
print(someInts1)



var threeDoubles = Array(repeating: 0.0, count: 3)
var fiveints = Array(repeating: 1.1, count: 5)
var result = threeDoubles + fiveints
print(result)

var list = ["milk","eggs"]
if list.isEmpty{
    print("list is empty")
}
else{
    print("list isn't empty")
}

list.append("Flour")
list += ["Baking Powder"]
list += ["Chocolate Spread", "Cheese", "Butter"]

var firstItem = list[0]
print(list)
list[0] = "Six eggs"
print(list)
list[4...6] = ["Bananas", "Apples"]
list.insert("Maple Syrup", at: 0)

print(list)

var nm: [Int: String] = [:]
nm[16] = "Sixteen"
nm = [:]

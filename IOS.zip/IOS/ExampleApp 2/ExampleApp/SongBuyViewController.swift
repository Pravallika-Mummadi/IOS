//
//  SongBuyViewController.swift
//  ExampleApp
//
//  Created by Pravallika Mummadi on 11/3/23.
//

import UIKit

class SongBuyViewController: UIViewController {

    @IBOutlet weak var Thankyoulabel: UILabel!
    @IBOutlet weak var Thankyouimg: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        
        Thankyouimg.image = UIImage(named: "thankyou")
        Thankyoulabel.text! = "Thank you for purchasing the Song😃"
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

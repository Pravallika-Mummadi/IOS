//
//  SongInfoViewController.swift
//  ExampleApp
//
//  Created by Pravallika Mummadi on 11/3/23.
//

import UIKit

class SongInfoViewController: UIViewController {

    @IBOutlet weak var SongimgOL: UIImageView!
    
    @IBOutlet weak var SongnameOL: UILabel!
    
    @IBOutlet weak var SingerOL: UILabel!
    
    
    @IBOutlet weak var LyricwriterOL: UILabel!
    
    
    @IBOutlet weak var MusicDirectorOL: UILabel!
    
    
    var songname = ""
    var singer = ""
    var lyricwriter = ""
    var musicdirector = ""
    var imagename = ""
    var cost = 0.0
    var discount = 0.0
    var tax = 0.0
    var price = 0.0
    var Songnames: [String] = []
    
    var array1 = [["Rahul Sipligunj","G.V. Prakash Kumar","Sid Sriram","Hesham Abdul Wahab","P. Raghu"],
                  ["Chandrabose","Anantha Sriram","MM Sreelekha","Shiva Nirvana","P. Raghu"],
                  ["M. M. Keeravaani","G.V. Prakash Kumar","Shadab Rayeen","Hesham Abdul Wahab","Midhun Mukundan"]]
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
  
            switch songname
        {
            case Songnames[0] :
                SongnameOL.text! += songname
                SingerOL.text! += array1[0][0]
                LyricwriterOL.text! += array1[1][0]
                MusicDirectorOL.text! += array1[2][0]
                SongimgOL.image = UIImage(named: imagename)
                self.SongimgOL.frame.origin.x = view.frame.width
                
            case Songnames[1] :
                SongnameOL.text! += songname
                SingerOL.text! += array1[0][1]
                LyricwriterOL.text! += array1[1][1]
                MusicDirectorOL.text! += array1[2][1]
                SongimgOL.image = UIImage(named: imagename)
                self.SongimgOL.frame.origin.x = view.frame.width

            case Songnames[2] :
                SongnameOL.text! += songname
                SingerOL.text! += array1[0][2]
                LyricwriterOL.text! += array1[1][2]
                MusicDirectorOL.text! += array1[2][2]
                SongimgOL.image = UIImage(named: imagename)
                self.SongimgOL.frame.origin.x = view.frame.width

            case Songnames[3] :
                SongnameOL.text! += songname
                SingerOL.text! += array1[0][3]
                LyricwriterOL.text! += array1[1][3]
                MusicDirectorOL.text! += array1[2][3]
                SongimgOL.image = UIImage(named: imagename)
                self.SongimgOL.frame.origin.x = view.frame.width

            case Songnames[4] :
                SongnameOL.text! += songname
                SingerOL.text! += array1[0][4]
                LyricwriterOL.text! += array1[1][4]
                MusicDirectorOL.text! += array1[2][4]
                SongimgOL.image = UIImage(named: imagename)
                self.SongimgOL.frame.origin.x = view.frame.width

            default :
                SongnameOL.text! += songname
                SingerOL.text! = " "
                LyricwriterOL.text! = " "
                MusicDirectorOL.text! = " "
                self.SongimgOL.frame.origin.x = view.frame.width
                
            }
    }
    override func viewDidAppear(_ animated: Bool) {
        UIView.animate(withDuration: 0.4){
            self.SongimgOL.frame.origin.x = 70
        }
    }
    
   
    @IBAction func SongPriceBTN(_ sender: Any) {
        switch songname
        {
        case Songnames[0]:
            cost = 23
            discount = 20
            tax = 5
            pricecalculator()
            
        case Songnames[1]:
            cost = 14
            discount = 13
            tax = 5
            pricecalculator()
    
        case Songnames[2]:
            cost = 18
            discount = 12
            tax = 5
            pricecalculator()
            
        case Songnames[3]:
            cost = 19
            discount = 30
            tax = 5
            pricecalculator()
            
        case Songnames[4]:
            cost = 43
            discount = 10
            tax = 5
            pricecalculator()
    
        default :
            cost = 0.0
            discount = 0.0
            tax = 0.0
            price = 0.0
        }
       
    
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if(transition == "songpriceSegue")
        {
            var destination = segue.destination as! SongPriceInfoViewController
            
            destination.cost = cost
            destination.discount = discount
            destination.tax = tax
            destination.price = Double(String(format: "%.2f",price)) ?? 0.0
            
        }
    }
    func pricecalculator(){
        
        price = (cost - ((cost * discount)/100)) + ((cost * tax)/100)
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

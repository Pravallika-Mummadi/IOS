//
//  ViewController.swift
//  Initials
//
//  Created by Pravallika Mummadi on 9/12/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL1: UITextField!
    
    @IBOutlet weak var inputOL2: UITextField!
    @IBOutlet weak var outputOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func onClick(_ sender: Any) {
        
        //read variables
        var firstname = inputOL1.text!
        var lastname = inputOL2.text!
        
        var fn =  firstname[firstname.startIndex].uppercased()
        var ln = lastname[lastname.startIndex].uppercased()
        
        outputOL.text = "\(fn).\(ln)"
        
    }
    
}


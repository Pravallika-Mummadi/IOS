//
//  ViewController.swift
//  MyOwnApp
//
//  Created by Pravallika Mummadi on 10/3/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var InputOL: UITextField!
    
    @IBOutlet weak var undergradstudentoptn: UITextField!
    
    @IBOutlet weak var InstructorOL: UILabel!
    @IBOutlet weak var CourseFeeOL: UILabel!
    @IBOutlet weak var CreditHrsOL: UILabel!
    @IBOutlet weak var imagedisplay: UIImageView!
    @IBOutlet weak var CNameoutputOL: UILabel!
    
    @IBOutlet weak var feeaftertax: UILabel!
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func ViewDetailsbutton(_ sender: UIButton) {
        
        //Read input from user
        var coursename = InputOL.text!.uppercased()
        var undergradornot = undergradstudentoptn.text!.uppercased()
        //When button is clicked
        //First display coursename entered
         CNameoutputOL.text! = "You have Entered \(coursename) as coursename"
        //then display details based on the course name
        if(coursename == "IOS")
        {
            //then display image based on the course name
            imagedisplay.image = UIImage(named: "IOS")
            //then display credit hrs for this course
            CreditHrsOL.text! = "3"
            if(undergradornot == "YES")
            {
                //Then Display course fee based on the credit hrs
                var Basefee = 500
                var credithrs = Int(CreditHrsOL.text!) ?? 0
                var fee = Basefee * credithrs
                var feeaftertax1 = (Double(fee) ?? 0.0 ) + ((Double(fee) ?? 0.0) * 0.20)
                CourseFeeOL.text! = String(fee)
                InstructorOL.text! = "Ajay Bandi"
                feeaftertax.text! = String(feeaftertax1)
            }
            else{
                //Then Display course fee based on the credit hrs
                var Basefee = 600
                var credithrs = Int(CreditHrsOL.text!) ?? 0
                var fee = Basefee * credithrs
                var feeaftertax1 = (Double(fee) ?? 0.0 ) + ((Double(fee) ?? 0.0) * 0.20)
                CourseFeeOL.text! = String(fee)
                InstructorOL.text! = "Ajay Bandi"
                feeaftertax.text! = String(feeaftertax1)
            }
        }
        if(coursename == "WEBAPPS")
        {
            //then display image based on the course name
            imagedisplay.image = UIImage(named: "WEBAPPS")
            //then display credit hrs for this course
            CreditHrsOL.text! = "3"
            if(undergradornot == "YES")
            {
                //Then Display course fee based on the credit hrs
                var Basefee = 600
                var credithrs = Int(CreditHrsOL.text!) ?? 0
                var fee = Basefee * credithrs
                var feeaftertax1 = (Double(fee) ?? 0.0 ) + ((Double(fee) ?? 0.0) * 0.20)
                CourseFeeOL.text! = String(fee)
                InstructorOL.text! = "Charles Hoot"
                feeaftertax.text! = String(feeaftertax1)
            }
            else{
                //Then Display course fee based on the credit hrs
                var Basefee = 700
                var credithrs = Int(CreditHrsOL.text!) ?? 0
                var fee = Basefee * credithrs
                var feeaftertax1 = (Double(fee) ?? 0.0 ) + ((Double(fee) ?? 0.0) * 0.20)
                CourseFeeOL.text! = String(fee)
                InstructorOL.text! = "Charles Hoot"
                feeaftertax.text! = String(feeaftertax1)
            }
            
        }
        if(coursename == "JAVA")
        {
            //then display image based on the course name
            imagedisplay.image = UIImage(named: "JAVA")
            //then display credit hrs for this course
            CreditHrsOL.text! = "3"
            if(undergradornot == "YES")
            {
                //Then Display course fee based on the credit hrs
                var Basefee = 700
                var credithrs = Int(CreditHrsOL.text!) ?? 0
                var fee = Basefee * credithrs
                var feeaftertax1 = (Double(fee) ?? 0.0 ) + ((Double(fee) ?? 0.0) * 0.20)
                CourseFeeOL.text! = String(fee)
                InstructorOL.text! = "Ratan Lal"
                feeaftertax.text! = String(feeaftertax1)
            }
            else{
                
                //Then Display course fee based on the credit hrs
                var Basefee = 800
                var credithrs = Int(CreditHrsOL.text!) ?? 0
                var fee = Basefee * credithrs
                var feeaftertax1 = (Double(fee) ?? 0.0 ) + ((Double(fee) ?? 0.0) * 0.20)
                CourseFeeOL.text! = String(fee)
                InstructorOL.text! = "Chandra Mouli"
                feeaftertax.text! = String(feeaftertax1)
            }
        }
        
        
        
        
    }
    
    
    
    
    
    
    
    
}


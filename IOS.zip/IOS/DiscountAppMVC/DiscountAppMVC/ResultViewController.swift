//
//  ResultViewController.swift
//  DiscountAppMVC
//
//  Created by Pravallika Mummadi on 10/31/23.
//

import UIKit

class ResultViewController: UIViewController {

    
    @IBOutlet weak var DisplayAmountOL: UILabel!
    
    
    @IBOutlet weak var DisplayDiscountRateOL: UILabel!
    
    @IBOutlet weak var DisplayPirceAfterDiscountOL: UILabel!
    
    
    @IBOutlet weak var DisplayImage: UIImageView!
    
    var amount = ""
    var discountrate = ""
    var priceAfterDiscount = 0.0
    var imagename = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        DisplayAmountOL.text! += amount
        DisplayDiscountRateOL.text! += discountrate
        DisplayPirceAfterDiscountOL.text! += String(priceAfterDiscount)
        
        DisplayImage.image = UIImage(named: imagename)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  ViewController.swift
//  DiscountAppMVC
//
//  Created by Pravallika Mummadi on 10/31/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var AmountOL: UITextField!
    
    
    @IBOutlet weak var DiscountRateOL: UITextField!
    
    var priceAfterDiscount = 0.0
    
    var imagename = " "
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func CalculateBtn(_ sender: UIButton) {
        var amount = Double(AmountOL.text!) ?? 0.0
        var discountrate = Double(DiscountRateOL.text!) ?? 0.0
        
        
         priceAfterDiscount = amount - ((amount * discountrate)/100)
        
        if(discountrate > 0.0)
        {
         imagename = "discount"
        }
        else
        {
            imagename = "nodiscount"
        }
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "resultSegue"
        {
            var destination = segue.destination as! ResultViewController
            
            destination.amount = AmountOL.text!
            destination.discountrate = DiscountRateOL.text!
            destination.priceAfterDiscount = priceAfterDiscount
            
            destination.imagename = imagename
        }
    }
    
}


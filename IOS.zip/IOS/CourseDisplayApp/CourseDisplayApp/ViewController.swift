//
//  ViewController.swift
//  CourseDisplayApp
//
//  Created by Pravallika Mummadi on 9/28/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imagedisplay: UIImageView!
    
    @IBOutlet weak var coursename: UILabel!
    @IBOutlet weak var coursenumber: UILabel!
    @IBOutlet weak var semesteroffered: UILabel!
    
    @IBOutlet weak var previousbuttonOL: UIButton!
    
    @IBOutlet weak var nextbuttonOL: UIButton!
    //array of courses
    var courses = [["img01","44542","Network Security","Fall 2023"],
                   ["img02","44543","ios","Fall 2023"],
                   ["img03","44544","Data Streaming","Summer 2024"]]
    
    var imageNumber = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //previous button is disabled
        previousbuttonOL.isEnabled = false
        
        //Display first course details
        updateDisplay(imageNumber)
        
        
    }

    @IBAction func previousbuttonClicked(_ sender: UIButton) {

        //next button should be enabled
        nextbuttonOL.isEnabled = true
        
        //decrement the imagenumber
        imageNumber -= 1
        
        //display details
        updateDisplay(imageNumber)
        
        
        //if reach beginning of array previous is disabled
        if(imageNumber == 0){
            previousbuttonOL.isEnabled = false
        }
    }
    
    @IBAction func nextbuttonClicked(_ sender: UIButton) {
        //previous button is enabled
        previousbuttonOL.isEnabled = true
        //display second course details
        imageNumber += 1
        
        //call updatedisplay method
        updateDisplay(imageNumber)
        //when reached end of array next button should be disabled
        if (imageNumber == courses.count-1){
            nextbuttonOL.isEnabled = false
        }
    }
    
    func updateDisplay(_ imageNumber:Int){
        //display second course details
        
        imagedisplay.image = UIImage(named: courses[imageNumber][0])
        coursenumber.text! = courses[imageNumber][1]
        coursename.text! = courses[imageNumber][2]
        semesteroffered.text! = courses[imageNumber][3]
    }
}


import UIKit

var greeting = "Hello, playground"

greeting.count

greeting+=", I have created a playground"

greeting.append(" on strings")

greeting.lowercased()

greeting[greeting.startIndex]

greeting[greeting.index(before: greeting.endIndex )]

var course = "444643-Mobile Computing-ios"

course[course.index(course.startIndex,offsetBy: 7)]

course[course.index(before: course.endIndex)]

course[course.index(after: course.startIndex)]

print(course.split(separator: " "))

course.remove(at: course.firstIndex(of: "i")!)
print(course)

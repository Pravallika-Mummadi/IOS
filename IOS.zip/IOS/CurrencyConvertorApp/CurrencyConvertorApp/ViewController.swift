//
//  ViewController.swift
//  CurrencyConvertorApp
//
//  Created by Pravallika Mummadi on 11/3/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var rupeeOL: UITextField!
    
    @IBOutlet weak var dollarOL: UITextField!
    
    
    var rupeetodollar = 0.0
    var dollartorupee = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }

    

    @IBAction func convertBTN(_ sender: UIButton) {
        var r = (Double(rupeeOL.text!) ?? 0.0)
        var d = (Double(dollarOL.text!) ?? 0.0)
        
         rupeetodollar =  round(r * 82)
         dollartorupee = round(d / 82)
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if(transition == "resultSegue")
        {
            var destination = segue.destination as! ResultViewController
            destination.r = String(rupeetodollar)
            destination.d = String(dollartorupee)
            
            
        
            
        }
    }
    
}


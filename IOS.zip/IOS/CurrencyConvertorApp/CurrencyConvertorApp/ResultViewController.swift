//
//  ResultViewController.swift
//  CurrencyConvertorApp
//
//  Created by Pravallika Mummadi on 11/3/23.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var Displayimagerupeetodollar: UIImageView!
    
    
    @IBOutlet weak var rptodollar: UILabel!
    
    
    
    @IBOutlet weak var Displayimagedollertorupee: UIImageView!
    
    @IBOutlet weak var dollartorp: UILabel!
    var r = ""
    var d = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        rptodollar.text! += r
        
        dollartorp.text! += d
        
        
        Displayimagerupeetodollar.image=UIImage(named: "dollarimg")
        
        Displayimagedollertorupee.image=UIImage(named: "rupee")
        self.Displayimagerupeetodollar.frame.origin.x = view.frame.width
        self.Displayimagedollertorupee.frame.origin.x = view.frame.width
        
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        UIView.animate(withDuration: 0.3){
            
            self.Displayimagerupeetodollar.frame.origin.x = 70
           
            
            self.Displayimagedollertorupee.frame.origin.x = 70
           
            
            

    }
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

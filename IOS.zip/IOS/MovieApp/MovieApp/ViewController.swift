//
//  ViewController.swift
//  MovieApp
//
//  Created by Pravallika Mummadi on 11/3/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


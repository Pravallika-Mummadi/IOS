//
//  ViewController.swift
//  Mummadi_CalculatorApp
//
//  Created by Pravallika Mummadi on 9/17/23.
//

import UIKit

class ViewController: UIViewController {
    
    var oper1:Double = 0.0
    var oper2:Double = 0.0
    var operator_ = "+"
    var result = 0.0
    var x = 0
    var y = 0.00
    
    
    @IBOutlet weak var resultOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func ACbutton(_ sender: UIButton) {
        resultOutlet.text! = ""
        
        
    }
    
    @IBAction func Cbutton(_ sender: UIButton) {
        if !resultOutlet.text!.isEmpty {
            resultOutlet.text!.removeLast()
        }
        
    }
   
    @IBAction func PrMbutton(_ sender: UIButton) {
        if !resultOutlet.text!.isEmpty {
             // Check if the current number is negative or positive and toggle the sign accordingly.
             if resultOutlet.text!.hasPrefix("-") {
                 resultOutlet.text!.remove(at: resultOutlet.text!.startIndex) // Remove the negative sign
             } else {
                 resultOutlet.text!.insert("-", at: resultOutlet.text!.startIndex) // Add a negative sign
             }
         }
       
       
    }
    @IBAction func DIVbutton(_ sender: UIButton) {
        oper1 = Double(resultOutlet.text!)!
        operator_ = "/"
        resultOutlet.text! = ""
    }
    
    
    @IBAction func Xbutton(_ sender: UIButton) {
        oper1 = Double(resultOutlet.text!)!
        operator_ = "*"
        resultOutlet.text! = ""
    }
    
    @IBAction func Minusbutton(_ sender: UIButton) {
        oper1 = Double(resultOutlet.text!)!
        operator_ = "-"
        resultOutlet.text! = ""
    }
    
    @IBAction func Plusbutton(_ sender: UIButton) {
        oper1 = Double(resultOutlet.text!)!
        operator_ = "+"
        resultOutlet.text! = ""
    }
    
    
    @IBAction func Percentbutton(_ sender: UIButton) {
        oper1 = Double(resultOutlet.text!)!
        operator_ = "%"
        resultOutlet.text! = ""
    }
    
    
    
    @IBAction func Sevenbutton(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "7"
    }
    
    @IBAction func Eightbutton(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "8"
    }
    
    @IBAction func Ninebutton(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "9"
    }
    
    @IBAction func Fourbutton(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "4"
    }
    
    @IBAction func Fivebutton(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "5"
    }
    
    
    @IBAction func Sixbutton(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "6"
    }
    
    
    @IBAction func Onebutton(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "1"
    }
    
    @IBAction func Threebutton(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "3"
    }
    
    @IBAction func Twobutton(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "2"
    }
    
    
    @IBAction func Zerobutton(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "0"
    }
    
    @IBAction func Dotbutton(_ sender: UIButton) {
        resultOutlet.text! = resultOutlet.text! + "."
    }
    
    
    @IBAction func Equalbutton(_ sender: UIButton) {
        oper2 = Double(resultOutlet.text!)!
        
            switch operator_ {
            case "+" : y = oper1 + oper2
                resultOutlet.text = y.truncatingRemainder(dividingBy: 1) == 0 ? String(Int(y)) : String(y)
                
            case "-" : x = Int(oper1 - oper2)
                resultOutlet.text = String(x)
                
            case "/" : result = oper1 / oper2
                if(result.isInfinite)
                {
                    resultOutlet.text!="Not a number"
                }
                else{
                    result = round(result * 100000) / 100000.0
                    resultOutlet.text = String(result)
                }
                
            case "*" : x = Int(oper1 * oper2)
                resultOutlet.text = String(x)
                
            case "%" : result = oper1.truncatingRemainder(dividingBy: oper2)
                result = round(result * 10) / 10.0
                resultOutlet.text = String(result)
                
            default : resultOutlet.text = ""
            }
        
    }
    
}
        

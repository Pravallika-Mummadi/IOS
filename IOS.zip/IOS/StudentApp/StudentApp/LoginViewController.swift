//
//  ViewController.swift
//  StudentApp
//
//  Created by Pravallika Mummadi on 11/7/23.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var sidOL: UITextField!
    
    var studentFound = Student()
    
    
    //guest user initially
    var isStudent = false
    
    //getting the array from swift file
    var studentsArray = students
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func StuDetailsBTN(_ sender: UIButton) {
        for student in studentsArray
        {
           var givenID = sidOL.text!
            if (givenID == student.sid)
            {
                studentFound = student
                //studnet is found
                isStudent = true
            }
        }
        
        
        }
    

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        
        if transition == "studentInfoSegue"
        {
            let destination = segue.destination as! StudentInfoViewController
            
            if isStudent{
                destination.studentobject = studentFound
            }
            else
            {
                destination.guestUser = isStudent
            }
            
        }
    }
    
    
}


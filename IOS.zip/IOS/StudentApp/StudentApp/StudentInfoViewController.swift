//
//  StudentInfoViewController.swift
//  StudentApp
//
//  Created by Pravallika Mummadi on 11/7/23.
//

import UIKit

class StudentInfoViewController: UIViewController {
    
    @IBOutlet weak var NameOL: UILabel!
    
    
    @IBOutlet weak var SIDOL: UILabel!
    
    
    @IBOutlet weak var EmailOL: UILabel!
    
    
    @IBOutlet weak var CourseBTNOL: UIButton!
    
    var studentobject = Student()
    var guestUser:Bool = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        if guestUser {
            
            EmailOL.isHidden = true
            NameOL.text = "Name: Guest User"
            SIDOL.isHidden = true
            CourseBTNOL.isHidden = true
            
        }else{
            
            
            EmailOL.text = "SID: " + studentobject.sid
            NameOL.text = "Email: " + studentobject.email
            SIDOL.text = "Name: " + studentobject.name
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        
        let transition = segue.identifier
        
        //We need to view courses of the logged in student in CourseViewController,
        // So we pass the courses from the 'studentObj' variable
        if transition == "coursesInfoSegue" {
            let destination = segue.destination as! CoursesInfoViewController
            
            
            destination.coursesArray = studentobject.courses
        }
        
        
      
        
    }
}

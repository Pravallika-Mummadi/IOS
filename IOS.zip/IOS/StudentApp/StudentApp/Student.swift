//
//  Student.swift
//  StudentApp
//
//  Created by Pravallika Mummadi on 11/7/23.
//

import Foundation

struct Student{
    var name = ""
    var sid = ""
    var email = ""
    
    var courses:[Course] = []
    
}

struct Course {
    var title = ""
    var sem = ""
}


let S1 = Student(name: "Pravallika",sid: "s555592",email: "s555592@nwmissouri.edu",
                       courses: [Course(title: "Java",sem: "Spring"),
                                 Course(title: "Patterns",sem: "Fall"),
                                 Course(title: "ADB",sem: "Summer")]
                        )

let S2 = Student(name: "Charishma",sid: "s123292",email: "s123292@nwmissouri.edu",
                       courses: [Course(title: "Webapps",sem: "Spring"),
                                 Course(title: "IOS",sem: "Summer"),
                                 Course(title: "DB",sem: "Fall")]
                        )

let S3 = Student(name: "Lalith",sid: "s111298",email: "s111298@nwmissouri.edu",
                       courses: [Course(title: "DB",sem: "Fall"),
                                 Course(title: "GDP",sem: "Spring"),
                                 Course(title: "Java",sem: "Summer")]
                        )

let students = [S1,S2,S3]

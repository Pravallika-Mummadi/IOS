//
//  ViewController.swift
//  Mummadi_Assignment02
//
//  Created by Pravallika Mummadi on 9/8/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var billAmountOutlet: UITextField!
    
    
    @IBOutlet weak var tipPercentageOutlet: UITextField!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    
    @IBOutlet weak var billAmountLabel: UILabel!
    
    @IBOutlet weak var tipAmountLabel: UILabel!
    
    @IBOutlet weak var totalAmountLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func SubmitBTN(_ sender: Any) {
        
        //Reading the inputs from text fields
        var name = nameOutlet.text!
        var billamount = billAmountOutlet.text!
        var tippercentage = tipPercentageOutlet.text!
        
        //Calculating the tip amount
        var tipamount = ((Double(billamount) ?? 0.0)*(Double(tippercentage) ?? 0.0))/100
        var totalbillamount = (Double(billamount) ?? 0.0)+tipamount
        
        
        // printing the Receipt
        nameLabel.text = ("Name: \(name)")
        billAmountLabel.text = ("Bill Amount: $\(Double(billamount) ?? 0.0)")
        tipAmountLabel.text = ("Tip Amount: $\(tipamount)")
        totalAmountLabel.text=("Total Amount: $\(totalbillamount)")
        
        
    }
    
    @IBAction func ResetBTN(_ sender: Any) {
        nameOutlet.text = ""
        billAmountOutlet.text = ""
        tipPercentageOutlet.text = ""
        
        
        nameLabel.text = ""
        billAmountLabel.text = ""
        tipAmountLabel.text = ""
        totalAmountLabel.text = ""
    }
}


//
//  ViewController.swift
//  BMIMVC
//
//  Created by Pravallika Mummadi on 11/2/23.
//

import UIKit

class ViewController: UIViewController {

    
    
    @IBOutlet weak var weightOL: UITextField!
    
    
    
@IBOutlet weak var heightOL: UITextField!
    var BMI = 0.0
    var imagename = " "
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func BMICalculate(_ sender: Any) {
        
        var weight = Double(weightOL.text!) ?? 0.0
        var height = Double(heightOL.text!) ?? 0.0
        
         BMI = (weight/(height*height)) * 703
        print("Hi")
        if(BMI <= 18.4)
        {
            imagename = "underweight"
        }
        else if (BMI >= 18.5 && BMI <= 24.9)
        {
            imagename = "normal"
        }
        else if (BMI >= 24.9 && BMI <= 39.9)
        {
            imagename = "overweight"
        }
        else
        {
            imagename = "obese"
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if(transition == "resultSegue")
        {
            var destination = segue.destination as! ResultViewController
            destination.weight = weightOL.text!
            destination.height = heightOL.text!
            destination.BMI = BMI
            
            destination.imagename = imagename
            
        }
    }
}


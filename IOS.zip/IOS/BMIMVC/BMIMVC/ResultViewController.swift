//
//  ResultViewController.swift
//  BMIMVC
//
//  Created by Pravallika Mummadi on 11/2/23.
//

import UIKit

class ResultViewController: UIViewController {

    
   
    
    @IBOutlet weak var DisplayWeight: UILabel!
    

    
    @IBOutlet weak var DisplayHeight: UILabel!
    
    @IBOutlet weak var DisplayBMI: UILabel!
    
    
    var weight = ""
    var height = ""
    var BMI = 0.0
    var imagename = " "
    
    @IBOutlet weak var DisplayImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        DisplayWeight.text! += weight
        DisplayHeight.text! += height
        DisplayBMI.text! += String(BMI)
        
        DisplayImage.image = UIImage(named: imagename)
        
        
        //increase width and height of the component
        var width = DisplayImage.frame.width
        width += 40
        
        var height = DisplayImage.frame.height
        height += 40
        
        var x = DisplayImage.frame.origin.x - 22
        print(x)
        var y = DisplayImage.frame.origin.x + 250
        print(y)
        
        
        //create rectangle object
        var largeframe = CGRect(x: x, y: y, width: width, height: height)
        UIView.animate(withDuration: 5, delay : 0, usingSpringWithDamping : 0.5, initialSpringVelocity : 1000 , animations : {
            self.DisplayImage.frame = largeframe
        })
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  SongPriceInfoViewController.swift
//  ExampleApp
//
//  Created by Pravallika Mummadi on 11/3/23.
//

import UIKit

class SongPriceInfoViewController: UIViewController {

    @IBOutlet weak var PriceimgOL: UIImageView!
    
    
    @IBOutlet weak var CostOL: UILabel!
    
    
    @IBOutlet weak var DiscountOL: UILabel!
    
    @IBOutlet weak var TaxOL: UILabel!
    
    
    @IBOutlet weak var PriceOL: UILabel!
    var songname = ""
    var cost = 0.0
    var discount = 0.0
    var tax = 0.0
    var price = 0.0
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
     
        CostOL.text! += String(cost)
        DiscountOL.text! = "Discount: \(String(discount)) %"
        TaxOL.text! = "Tax: \(String(tax)) %"
        PriceOL.text! += String(price)
    
    }
    

    
    @IBAction func BuySongBtn(_ sender: Any) {
    }
    
   
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

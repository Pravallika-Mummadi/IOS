//
//  ViewController.swift
//  ExampleApp
//
//  Created by Pravallika Mummadi on 11/3/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var SongOL: UITextField!
    
    @IBOutlet weak var SongBTNOL: UIButton!
    
    
    
    var Songs = ["naatu","neeve","urike","na roja nuve","lingidi"]
    
    var images = ["NatuNatu","neeve","urikeurike","narojanuve","lingidi"]
    
    var imagename = " "
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func SongBtn(_ sender: UIButton) {
    
        
        var songname = SongOL.text!.lowercased()

        print(songname)
        if(Songs.contains(songname))
        {
            
            switch songname
            {
            case Songs[0] :
                imagename = images[0]
            case Songs[1] :
                imagename = images[1]
            case Songs[2] :
                imagename = images[2]
            case Songs[3] :
                imagename = images[3]
            case Songs[4] :
                imagename = images[4]
            default : imagename = images[0]
            }
        }
        }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

        let transition = segue.identifier
        if transition == "songinfoSegue" {
            let destination = segue.destination as! SongInfoViewController
            destination.songname = SongOL.text!
            destination.imagename = imagename
            destination.Songnames = Songs
        }
        
        
        
    }
}


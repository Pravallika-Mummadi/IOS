//
//  ViewController.swift
//  Mummadi_WordGuess
//
//  Created by Pravallika Mummadi on 10/12/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    
    
    @IBOutlet weak var guessLetterOL: UIButton!
    
    @IBOutlet weak var hintLabel: UILabel!
    
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var playAgainOL: UIButton!
    
    
    @IBOutlet weak var displayImage: UIImageView!
    
    
    
    var words = [["JAVA", "Programming Language"],
                 ["CAT", "Animal"],
                 ["BIKE", "Two wheeler"],
                 ["IPHONE", "Apple device"],
                 ["SONY", "Android device"]]
    var images = [["JAVA"],
                  ["CAT"],
                  ["BIKE"],
                  ["IPHONE"],
                  ["SONY"]]
    var count = 0;
    var word = ""
    var letterGuessed = ""
    var imagenum = 0
    var a = 0
    var b = 5
    var c = 0
    let maxNumOfWrongGuesses = 10
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        guessLetterOL.isEnabled = false
        playAgainOL.isHidden = true
        word = words[count][0]
        userGuessLabel.text = ""
        updateUnderscores();
        hintLabel.text = "Hint:"+words[count][1]
        statusLabel.text = ""
        wordsGuessedLabel.text = wordsGuessedLabel.text! + "\(a)"
        wordsRemainingLabel.text = wordsRemainingLabel.text! + "\(b)"
        totalWordsLabel.text = totalWordsLabel.text! + "5"
        guessCountLabel.text = "You have made " + "\(c)" + " guesses"
    }
    
    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
        c += 1
        
        var letter = guessLetterField.text!
        
        letterGuessed = letterGuessed + letter
        var shownword = ""
        for l in word{
            if letterGuessed.contains(l){
                shownword += "\(l)"
            }
            else{
                shownword += "_ "
            }
        }
        
        
        userGuessLabel.text = shownword
        guessLetterField.text = ""
        guessCountLabel.text = "You have made " + "\(c)" + " guesses"
        
        
        if c > maxNumOfWrongGuesses {
            guessCountLabel.text = "You have used all the available guesses, please play again"
            playAgainOL.isHidden = false
            count -= 1
            imagenum -= 1
        }
        
        
        if userGuessLabel.text!.contains("_") == false{
            playAgainOL.isHidden = false;
            guessLetterOL.isEnabled = false;
            
            displayImage.image = UIImage(named: images[imagenum][0])
            wordsGuessedLabel.text = wordsGuessedLabel.text! + ""
            a += 1
            b -= 1
            
            wordsGuessedLabel.text = "Total number of words guessed successfully: " + "\(a)"
            wordsRemainingLabel.text = "Total number of words remaining in game:" + "\(b)"
            guessCountLabel.text = "Wow! You have made \(c) guesses to guess the word!"
        }
        guessLetterOL.isEnabled = false
    }
    
    
    
    
    @IBAction func playAgainButtonPressed(_ sender: UIButton) {
        playAgainOL.isHidden = true
        
        letterGuessed = ""
        count += 1
        
        imagenum += 1
        
        if count == words.count{
            
            statusLabel.text = "Congratulations! You are done with the game!\rPlease start over again"
            userGuessLabel.text = ""
            guessCountLabel.text = ""
            hintLabel.text = ""
            playAgainOL.isHidden = false
            displayImage.image = UIImage(named: "ALL DONE")
        }
        else{
            if(count >= 6) {
                count = 0
                imagenum = 0
                a = 0
                b = 5
                wordsGuessedLabel.text = "Total number of words guessed successfully: " + "\(a)"
                wordsRemainingLabel.text = "Total number of words remaining in game:" + "\(b)"
                statusLabel.text = ""
            }
            word = words[count][0]
            
            hintLabel.text = "Hint: "
            hintLabel.text! += words[count][1]
            
            guessLetterOL.isEnabled = true
            displayImage.image = UIImage(named: "")
            userGuessLabel.text = ""
            updateUnderscores()
            c = 0
            guessCountLabel.text = "You have made " + "\(c)" + " guesses"
        }
    }
    
    @IBAction func guessLetterAction(_ sender: Any) {
        var textEntered = guessLetterField.text!;
        textEntered = String(textEntered.last ?? " ").trimmingCharacters(in: .whitespaces)
        guessLetterField.text = textEntered
        
        if textEntered.isEmpty{
            guessLetterOL.isEnabled = false
        }
        else{
            guessLetterOL.isEnabled = true
        }
    }
    func updateUnderscores(){
        for letter in word{
            userGuessLabel.text! += "- "
        }
        
    }
    
}

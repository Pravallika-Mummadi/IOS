import UIKit

var greeting = "Hello, playground"

func greetUser(){
    print("Welcome")
}
greetUser()

func sayhello()->String{
    var name="Swift"
    return "Hello "+name+"!"
}

print(sayhello())



func sumAndAvg(_ numbers:Double...)->(sum:Double,avg:Double){
    var total:Double = 0
    var avg:Double
    for number in numbers{
        total+=number
    }
    avg = total/Double(numbers.count)
    return (total,avg)
}

let result = sumAndAvg(1,23,3.4,456,10,2,43)
print("Sum = \(result.sum)")
print("average = \(result.avg)")


func favouriteProgram(name:String)->String{
    var name="fav Swift program is \(name)"
    return name
}

func addNumbers(number1:Int,number2:Int)->Int{
    return number1+number2
}

print("Sum of numbers is \(addNumbers(number1: 10, number2: 20))")



func manipulateNumber(input: Int,mode: Bool)->String{
    var counter=input
    if(mode){
        counter+=2
    }
    else{
        counter-=1
    }
    
    return "The \(mode ? "incremented" : "decremented") value is \(counter)"
}
var val=12
print(manipulateNumber(input: val+987, mode: true))

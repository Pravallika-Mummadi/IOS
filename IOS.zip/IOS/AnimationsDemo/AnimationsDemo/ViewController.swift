//
//  ViewController.swift
//  AnimationsDemo
//
//  Created by Pravallika Mummadi on 10/24/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageDisplayOL: UIImageView!
    
    @IBOutlet weak var HappyOL: UIButton!
    
    @IBOutlet weak var SadOL: UIButton!
    
    @IBOutlet weak var AngryOL: UIButton!
    
    @IBOutlet weak var ShakemeOL: UIButton!
    
    @IBOutlet weak var ShowmeOL: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func viewDidAppear(_ animated: Bool) {
        // move the image view outside of the view
        imageDisplayOL.frame.origin.x = view.frame.maxX
        
        //Similarly move other components outside of the screen
        HappyOL.frame.origin.x = view.frame.width
        SadOL.frame.origin.x = view.frame.width
        AngryOL.frame.origin.x = view.frame.width
        ShakemeOL.frame.origin.x = view.frame.width
        
    }
    
    
    @IBAction func HappyBTNClicked(_ sender: UIButton) {
        UpdateandAnimate("happy")
    }
    @IBAction func SadBTNClicked(_ sender: UIButton) {
        UpdateandAnimate("sad")
    }
    @IBAction func AngryBTNClicked(_ sender: UIButton) {
        UpdateandAnimate("angry")
    }
    @IBAction func ShakeMeBTNClicked(_ sender: UIButton) {
    
        //increase width and height of the component
        var width = imageDisplayOL.frame.width
        width += 40
        
        var height = imageDisplayOL.frame.height
        height += 40
        
        var x = imageDisplayOL.frame.origin.x
        print(x)
        var y = imageDisplayOL.frame.origin.y-20
        
        //create rectangle object
        var largeframe = CGRect(x: x, y: y, width: width, height: height)
        UIView.animate(withDuration: 1, delay : 0, usingSpringWithDamping : 1, initialSpringVelocity : 1000 , animations : {
            self.imageDisplayOL.frame = largeframe
        })
        
    }
    
    @IBAction func ShowMeBTNClicked(_ sender: UIButton) {
        UIView.animate(withDuration: 1, animations: {
            //moving all components to center
            
            self.imageDisplayOL.center.x = self.view.center.x
            
            self.HappyOL.center.x = self.view.center.x
            self.SadOL.center.x = self.view.center.x
            self.AngryOL.center.x = self.view.center.x
            self.ShakemeOL.center.x = self.view.center.x
        })
        //disable show me button
        ShowmeOL.isEnabled = false
    }
    
    
    
    func UpdateandAnimate(_ imageName:String){
        //make the current image as opaque(in order to make it opaque weh have to use alpha where it shoud be zero)
        UIView.animate(withDuration: 1, animations: {
            self.imageDisplayOL.alpha = 0
        })
        
        //Assign the new image to animation and make it transparent (alpha should be one)
        UIView.animate(withDuration: 1,delay: 0.5, animations: {
            self.imageDisplayOL.alpha = 1
            self.imageDisplayOL.image = UIImage(named: imageName)
            
        })
        
    }
}


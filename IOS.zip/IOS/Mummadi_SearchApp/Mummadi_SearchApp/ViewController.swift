//
//  ViewController.swift
//  Mummadi_SearchApp
//
//  Created by Pravallika Mummadi on 10/29/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    @IBOutlet weak var searchBtn: UIButton!
    
    @IBOutlet weak var PrevBtn: UIButton!
    
    @IBOutlet weak var ResetBtn: UIButton!
   
    @IBOutlet weak var NextBtn: UIButton!
    
    
    var imagesarray = [
               ["anushka","ileana","kajal","nivetha","trisha"],
               ["bradpitt","chrisevans","hemsworth","jackiechan","johnnydepp"],
               ["magnolia","roses","sunflower","jasmine","chamomile"]
             ]
   
   var actress_keywords = ["actress","heroine","actressfilm","femaleactress"]
   var actor_keywords =  ["actor","hero","actorfilm","maleactor"]
   var flower_keywords = ["flower","blossom","bloom","flowerodour"]
                            
   var topicsnumber = 0
   var imagenumber = 0
    
   var topics_array = [
                       ["Anushka Shetty, born on November 7, 1981, is a renowned Indian actress primarily working in the Telugu and Tamil film industries. She gained fame for her role as Devasena in the epic film Baahubali which catapulted her to international stardom. Anushka is celebrated for her versatile acting skills and dedication to her craft. She's won numerous awards for her performances, including Awards.",
                       "Ileana D'Cruz is an Indian film actress and model known for her work in the Bollywood and Telugu film industries. She was born on November 1, 1987, in Mumbai, India. Ileana made her acting debut in the Telugu film Devadasu in 2006, which earned her critical acclaim. ",
                        "Kajal Aggarwal is an Indian actress born on June 19, 1985, in Mumbai, India. She is renowned for her work in the South Indian film industry, primarily in Telugu and Tamil cinema. Kajal made her acting debut in the 2004 Bollywood film Kyun! Ho Gaya Na... but gained widespread recognition in the South Indian film industry with movies like Magadheera and Darling. ",
                        "Nivetha Thomas is a talented Indian actress known for her work in the Telugu and Malayalam film industries. Born on October 2, 1995, in Kannur, Kerala, she made her acting debut as a child artist in the Malayalam film Veruthe Oru Bharya in 2008. She gained widespread recognition for her lead role in the critically acclaimed film Ninnu Kori (2017) opposite Nani.",
                        "Trisha Krishnan, commonly known as Trisha, is a renowned Indian actress born on May 4, 1983, in Chennai, Tamil Nadu. She started her career in the South Indian film industry, making her acting debut in the Tamil film Jodi in 1999. Trisha quickly gained fame for her versatile acting skills and beauty.She has acted in numerous Tamil, Telugu, and even a few Hindi films."],
                       ["Brad Pitt is a renowned American actor and producer, born on December 18, 1963, in Shawnee, Oklahoma. He gained fame for his roles in films like Fight Club,Inglourious Basterds, and The Curious Case of Benjamin Button. Pitt has received numerous awards, including an Academy Award for his role in 12 Years a Slave, and is known for his philanthropic efforts and A-list status in Hollywood.",
                        "Chris Evans is an American actor best known for his role as Captain America in the Marvel Cinematic Universe. He was born on June 13, 1981, in Boston, Massachusetts. In addition to his superhero role, Evans has appeared in various other films and has been praised for his philanthropic efforts. He announced a break from acting in 2021 to focus on directing.",
                        "Chris Hemsworth is an Australian actor best known for his portrayal of Thor in the Marvel Cinematic Universe. Born on August 11, 1983, in Melbourne, he comes from a family of actors, including his brother, Liam Hemsworth. Chris has received critical acclaim for his role as the God of Thunder and is known for his impressive physique and charismatic on-screen presence.",
                        "Jackie Chan is a renowned Hong Kong actor, martial artist, and filmmaker known for his acrobatic fighting style and impressive stunt work. He gained international fame for his roles in movies like Rush Hour and Police Story. Jackie Chan is celebrated for performing his own stunts and has a prolific career spanning several decades. He's also a philanthropist and cultural ambassador.",
                       "Johnny Depp is a renowned American actor, producer, and musician. He gained fame for his versatile roles in films like Pirates of the Caribbean,Edward Scissorhands, and Sweeney Todd. Depp's unique and eccentric acting style has made him a beloved figure in the entertainment industry. He has faced legal battles and controversies in recent years but continues to be a icon."],
                       ["Magnolias are beautiful flowering trees and shrubs known for their fragrant, large, and often white or pink blossoms. They belong to the family Magnoliaceae and have been around for millions of years, making them one of the oldest flowering plant species. Magnolias are popular in landscaping and gardening due to their stunning blooms and ornamental value.",
                        "Roses, the symbol of love and beauty, are a timeless and cherished flower known for their enchanting fragrance and vibrant colors. These exquisite blooms have captivated hearts for centuries, adorning gardens, expressing affection, and inspiring poets and artists with their elegance. With their delicate petals and thorny stems, roses embody the duality of life's beauty and its challenges. ",
                        "Sunflowers, scientifically known as Helianthus, are iconic plants renowned for their bright and radiant appearance. These tall, vibrant blooms feature a large, disk-shaped center filled with tiny, edible seeds. Sunflowers are not only a symbol of positivity and warmth but also serve as a valuable source of oil and food products, making them a popular choice in gardens and agricultural fields worldwide. ",
                        "Jasmine is a fragrant flowering plant known for its aromatic white or yellow blossoms. It is a popular choice in gardens and as an ornamental plant due to its delightful scent. Jasmine is also used in perfumes and teas, and its essential oils are valued for their therapeutic properties. This versatile plant adds a touch of beauty and relaxation to various aspects of life.",
                        "Chamomile is a popular herb known for its soothing and calming properties. It is commonly used in herbal teas and aromatherapy to promote relaxation and alleviate stress. Chamomile is also valued for its potential health benefits, such as aiding digestion and reducing inflammation. Its delicate, daisy-like flowers have a mild, pleasant flavor, making it a cherished ingredient in traditional and natural remedies."
                       ]
                      ]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        
        //disable all buttons
        PrevBtn.isHidden = true
        NextBtn.isHidden = true
        ResetBtn.isHidden = true
        searchBtn.isEnabled = false
        
        topicInfoText.isHidden = true
        topicInfoText.text! = " "
        
       
        
    }

   
    @IBAction func searchButtonAction(_ sender: UIButton) {
        searchBtn.isEnabled = true
        topicInfoText.isHidden = false
        
        PrevBtn.isHidden = false
        NextBtn.isHidden = false
        ResetBtn.isHidden = false
        
        
        PrevBtn.isEnabled = false
        NextBtn.isEnabled = true
        ResetBtn.isEnabled = true
        
        if (actress_keywords.contains (searchTextField.text!))
        {
            topicsnumber = 1
            resultImage.image = UIImage(named: imagesarray[0][0])
            topicInfoText.text = topics_array[0][0]
        }
        else if (actor_keywords.contains (searchTextField.text!))
        {
            topicsnumber = 2
            resultImage.image = UIImage(named: imagesarray[1][0])
            topicInfoText.text = topics_array[1][0]
        }
        else if (flower_keywords.contains (searchTextField.text!))
        {
            topicsnumber = 3
            resultImage.image = UIImage(named: imagesarray[2][0])
            topicInfoText.text = topics_array[2][0]
        }
        else
        {
            PrevBtn.isHidden = true
            NextBtn.isHidden = true
            ResetBtn.isHidden = true
            resultImage.image = UIImage(named: "oops")
            topicInfoText.text! = " "
        }
        
        
    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
        PrevBtn.isEnabled = true
        NextBtn.isEnabled = true
        imagenumber = imagenumber-1
        if topicsnumber == 1
        {
            resultImage.image = UIImage(named: imagesarray[0][imagenumber])
            topicInfoText.text = topics_array[0][imagenumber]
        }
        else if topicsnumber == 2
        {
            resultImage.image = UIImage(named: imagesarray[1][imagenumber])
            topicInfoText.text = topics_array[1][imagenumber]
        }
        else if topicsnumber == 3
        {
            resultImage.image = UIImage(named: imagesarray[2][imagenumber])
            topicInfoText.text = topics_array[2][imagenumber]
        }
        
        
        // disable previous button when on first page
        if imagenumber == 0
        {
            PrevBtn.isEnabled = false
        }
        else
        {
            PrevBtn.isEnabled = true
        }
        
    }
    
    @IBAction func ResetBtn(_ sender: UIButton) {
        PrevBtn.isHidden = true
        NextBtn.isHidden = true
        ResetBtn.isHidden = true
        
        searchTextField.text = ""
        imagenumber = 0
        topicsnumber = 0
        topicInfoText.isHidden = true
        topicInfoText.text! = " "
        resultImage.image = UIImage(named: "welcome")
     
        
    }
    
    @IBAction func ShowNextImagesBtn(_ sender: UIButton) {
        NextBtn.isEnabled = true
        PrevBtn.isEnabled = true
        imagenumber = imagenumber+1
        if topicsnumber == 1
        {
            resultImage.image = UIImage(named: imagesarray[0][imagenumber])
            topicInfoText.text = topics_array[0][imagenumber]
        }
        else if topicsnumber == 2
        {
            resultImage.image = UIImage(named: imagesarray[1][imagenumber])
            topicInfoText.text = topics_array[1][imagenumber]
        }
        else if topicsnumber == 3
        {
            resultImage.image = UIImage(named: imagesarray[2][imagenumber])
            topicInfoText.text = topics_array[2][imagenumber]
        }
        
        if (imagenumber == imagesarray[0].count - 1)
        {
            NextBtn.isEnabled = false
        }
        else
        {
            NextBtn.isEnabled = true
        }
    }
    
    @IBAction func searchtextField(_ sender: Any) {
        if searchTextField.text!.isEmpty
        {
            searchBtn.isEnabled = false
        }
        else
        {
            searchBtn.isEnabled = true
        }
    }
    
}


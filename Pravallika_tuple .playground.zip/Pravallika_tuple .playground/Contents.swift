import UIKit

var greeting = "Hello, playground"

var httperror = (error: 504 , errormessage : "Connection failed", timelimit : 12,345)
print(httperror)
print(httperror.0)
print(httperror.1,httperror.timelimit,httperror.3, terminator : "^ ")

//
//  ViewController.swift
//  EventsHub
//
//  Created by Pravallika Mummadi on 11/20/23.
//

import UIKit

class HomeScreenViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


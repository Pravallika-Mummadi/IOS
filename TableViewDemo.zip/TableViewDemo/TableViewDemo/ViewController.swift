//
//  ViewController.swift
//  TableViewDemo
//
//  Created by Pravallika Mummadi on 11/9/23.
//

import UIKit
class Product {
    var name: String?
    var category: String?
    
    init(name: String? = nil, category: String? = nil) {
        self.name = name
        self.category = category
    }
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return the no of products
        return productsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // create the cell and using no of times
        var cell = tableViewOL.dequeueReusableCell(withIdentifier: "reusableCell", for: indexPath)
        
        
        //populate the cell
        cell.textLabel?.text = productsArray[indexPath.row].name
        
        
        // return the cell
        return cell
    }
    

    var productsArray = [Product]()
    @IBOutlet weak var tableViewOL: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        let product1 = Product(name: "Macbook Pro",category: "Laptop")
        let product2 = Product(name: "iPhone ",category: "Cell Phone")
        let product3 = Product(name: "Airpods ",category: "Headsets")
        let product4 = Product(name: "iWatch ",category: "Accessories")
        let product5 = Product(name: "Charger ",category: "Accessories")
  
        productsArray.append(product1)
        productsArray.append(product2)
        productsArray.append(product3)
        productsArray.append(product4)
        productsArray.append(product5)
        
        // same file we have table
        tableViewOL.delegate = self
        // same file we have data i.e, same class file as data source
        tableViewOL.dataSource = self
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        var destination = segue.destination as! ProductsDescriptionViewController
        
        if transition == "productDetails"
        {
            destination.product = productsArray[(tableViewOL.indexPathForSelectedRow?.row)!]
            
            
            
            
        }
    }


}


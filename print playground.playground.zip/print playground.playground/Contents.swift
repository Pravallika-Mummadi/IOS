import UIKit

var greeting = "Hello, playground"
print("Welcome to swift programming");
print("Hi" , 123, 23.45);

var programlang = "Swift";
print(programlang)

let x = 20
print("x value is ",x);

var age = 26
print("\rYou are \(age) year old and you were once \(age/2) years")

print("""
Hi,
Welcome to IOS
Class!
""")

print("""
Your age is
\(x)
""")


print("\rHello,\rThis is BOBBY")

let Stringmessage = "HI!"
print("\r\(Stringmessage)","So i gave this as a message")

print(23, "String", 23.56 ,"🥸", separator: "#")

print("HI HELLO ALL")
print("********")
print("THIS IS IOS CLASS ",terminator: "@")
print("Fall 2023")



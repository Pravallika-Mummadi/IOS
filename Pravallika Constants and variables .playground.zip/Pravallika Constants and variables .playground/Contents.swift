import UIKit

var greeting = "Hello, playground"

var laptopbrand = "Apple"
laptopbrand = "HP"
print(laptopbrand)

let pi = 3.14
//pi = 4.56 Cannot assign to value: 'pi' is a 'let' constant
print(pi)


var price: Double = 34.45
price = price*2
print(price)

var message="This is nice and goood"
print(message)
print("message")

var c1 = "Windows"
var c2 = "IOS"
print(c1,"-",c2)
print(c1,c2,separator: "$")

print(1,2,3)
print(1.2,3.45)
